const Anthropic = require('@anthropic-ai/sdk');

exports.handler = async (event, context) => {
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { decision, stake, time, rep, context: userContext, podcastKnowledge } = JSON.parse(event.body);

    // Initialize Anthropic client
    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY
    });

    const prompt = `You are an expert leadership analyst for "PRESSURE by The Business End" - a platform that analyses high-stakes business decisions by matching them against judgment calls from elite sport leaders.

PODCAST DATABASE - These are real quotes and insights from The Business End podcast guests:
${podcastKnowledge}

USER'S DECISION TO ANALYSE:
Decision: ${decision}
Stakes: ${stake}
Time pressure: ${time ? 'Yes' : 'No'}
Reputation at risk: ${rep ? 'Yes' : 'No'}
Additional context: ${userContext || 'None provided'}

Analyse this decision and respond with ONLY a valid JSON object (no markdown, no explanation) in this exact format:
{
  "call": "DO" or "DONT" or "DELAY",
  "reasoning": "Brief explanation of why this recommendation (1-2 sentences)",
  "leaderName": "Name of the most relevant podcast guest to match with",
  "leaderRole": "Their role/title from the database",
  "matchScore": number between 70-95,
  "quote": "A relevant quote from that leader (use their actual keyInsight or paraphrase appropriately)",
  "signal": "Specific pressure analysis for this decision (2-3 sentences about what pressures are at play)",
  "risk": "The hidden cost or system risk of inaction or wrong action (1-2 sentences with specific implications)",
  "context": "How the matched leader's experience relates to this specific decision (2-3 sentences)",
  "action": "Three specific, actionable steps numbered 1. 2. 3. tailored to this decision",
  "biasName": "Name of likely cognitive bias (e.g. SUNK COST, EGO PROTECTION, GUILT-DRIVEN DELAY, REPUTATION AVOIDANCE, STANDARDS EROSION)",
  "biasText": "Explanation of how this bias might be affecting the decision (1-2 sentences)"
}

Be specific to the actual decision described. Match with the most relevant leader based on the situation type. Provide genuinely useful analysis.`;

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages: [
        { role: 'user', content: prompt }
      ]
    });

    // Parse the response
    let analysisText = message.content[0].text;
    // Clean up any markdown formatting
    analysisText = analysisText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    
    const analysis = JSON.parse(analysisText);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify(analysis)
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Analysis failed: ' + error.message })
    };
  }
};
